package com.skillrisers.gaming;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;
import javax.swing.Timer;

import com.skillrisers.gaming.sprites.KenPlayer;
import com.skillrisers.gaming.sprites.Power;
import com.skillrisers.gaming.sprites.RyuPlayer;
import com.skillrisers.gaming.utils.GameConstants;
import com.skillrisers.gaming.utils.PlayerConstants;

public class Board extends JPanel implements GameConstants , PlayerConstants{
	private BufferedImage backgroundImage;
	private RyuPlayer ryu_player;
	private KenPlayer ken_player;
	private Timer timer;
	private Power ryu_power;
	private Power ken_power;
	private boolean isGameOver;
	
	
	public Board() throws IOException{
		loadBackgroundImage();
		 ryu_player = new RyuPlayer();
		 ken_player = new KenPlayer();
		 setFocusable(true);
		 bindEvents();
		 gameLoop();
		 loadPower();
	}
	
	private void loadPower() {
		ryu_power = new Power(20, "Ryu".toUpperCase());
		ken_power = new Power(GWIDTH/2 + 80, "Ken".toUpperCase());
	}
	
	private void paintPower(Graphics pen) {
		ryu_power.printBox(pen);
		ken_power.printBox(pen);
	}
	
	private boolean isCollide() {
		int xDistance = Math.abs(ryu_player.getX() - ken_player.getX());
		int yDistance = Math.abs(ryu_player.getY() - ken_player.getY());
		int maxW = Math.max(ryu_player.getW(),ken_player.getW());		
		int maxH = Math.max(ryu_player.getH(),ken_player.getH());		
		return (xDistance <=maxW && yDistance <=maxH );
	}
	
	
	public void collision() {
		if((isCollide())) {
			if(ryu_player.isAttacking()) {
				ken_player.setCurrentMove(DAMAGE);
				ken_power.setHealth();
			}
			
			if(ken_player.isAttacking()) {
				ryu_player.setCurrentMove(DAMAGE);
				ryu_power.setHealth();
			}
			
			if(ken_power.getHealth() <= 0 || ryu_power.getHealth() <=0) {
				isGameOver = true;
			}
			ryu_player.setCollide(true);
			ken_player.setCollide(true);
			ryu_player.setSpeed(0);
			ken_player.setSpeed(0);
		}
		
		else {
			ryu_player.setSpeed(SPEED);
			ken_player.setSpeed(SPEED);
		}
	}
	
	private void printMessage(Graphics pen) {
		pen.setColor(Color.RED);
		pen.setFont(new Font("times",Font.BOLD,40));
		pen.drawString("Game Over",GWIDTH/2,GHEIGHT/2);
	}
	
	private void gameLoop() {
		timer = new Timer(50 , new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				repaint();
				ryu_player.fall();
				ken_player.fall();
				collision();
			}
		});
		
		timer.start();
	}
	private void loadBackgroundImage() throws IOException{
		backgroundImage = ImageIO.read(Board.class.getResource("bg.jpg"));
	}
	
	private void bindEvents() {
		this.addKeyListener(new KeyAdapter() {
			
			@Override
			public void keyReleased(KeyEvent e) {
				ryu_player.setSpeed(0);
				ken_player.setSpeed(0);
			}
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode() == KeyEvent.VK_LEFT) {
					if(ryu_player.getX()  <= 0) {
						ryu_player.setSpeed(0);
						ryu_player.setOutOfScreen(true);
					}
					
					else {						
						ryu_player.setSpeed(-SPEED);
						ryu_player.setCurrentMove(WALK);
						ryu_player.move();
						ryu_player.setCollide(false);
					}
					repaint();
				}
				else if(e.getKeyCode() == KeyEvent.VK_RIGHT) {
					if(ryu_player.isCollide()) {
						ryu_player.setSpeed(0);						
					}
					
					else if(ryu_player.isOutOfScreen()){
						ryu_player.setSpeed(DEFAULT_SPEED);
						ryu_player.setOutOfScreen(false);
					}
					else {
						ryu_player.setCollide(false);
						ken_player.setCollide(false);
						ryu_player.setSpeed(SPEED);					
					}
					ryu_player.setCurrentMove(WALK);
					ryu_player.move();
					repaint();
				}
				
				else if(e.getKeyCode() == KeyEvent.VK_UP) {
					ryu_player.jump();
					ryu_player.setCurrentMove(JUMP);
				}
				
				else if(e.getKeyCode() == KeyEvent.VK_K) {
					ryu_player.setAttacking(true);
					ryu_player.setCurrentMove(KICK);
				}
				
				else if(e.getKeyCode() == KeyEvent.VK_P) {
					ryu_player.setAttacking(true);
					ryu_player.setCurrentMove(PUNCH);
				}
				
				else if(e.getKeyCode() == KeyEvent.VK_A){
					if(ken_player.isCollide()) {
						ken_player.setSpeed(0);						
					}
					
					else if(ken_player.isOutOfScreen()){
						ken_player.setSpeed(-DEFAULT_SPEED);
						ken_player.setOutOfScreen(false);
					}
					
					else {
						ken_player.setCollide(false);
						ryu_player.setCollide(false);
						ken_player.setSpeed(-SPEED);					
					}
					ken_player.setCurrentMove(WALK);
					ken_player.move();
					repaint();
				}
				
				else if(e.getKeyCode() == KeyEvent.VK_N) {
					ken_player.setAttacking(true);
					ken_player.setCurrentMove(KICK);
				}
				
				else if(e.getKeyCode() == KeyEvent.VK_M) {
					ken_player.setAttacking(true);
					ken_player.setCurrentMove(PUNCH);
				}
				
				else if(e.getKeyCode() == KeyEvent.VK_D) {
					if(ken_player.getX()  >= 1420) {
						ken_player.setSpeed(0);
						ken_player.setOutOfScreen(true);
					}
					
					else {						
						ken_player.setSpeed(SPEED);
						ken_player.setCurrentMove(WALK);
						ken_player.move();
						ken_player.setCollide(false);
					}
					repaint();
				}
				
				else if(e.getKeyCode() == KeyEvent.VK_W) {
					ken_player.jump();
					ken_player.setCurrentMove(JUMP);
				}
			}
			
			
		});
	}
	
	@Override
	public void paintComponent(Graphics g) {
			super.paintComponent(g);
			g.drawImage(backgroundImage, 0, 0, GWIDTH, GHEIGHT, null);
			ryu_player.printPlayer(g);
			ken_player.printPlayer(g);
			paintPower(g);
			if(isGameOver) {
				printMessage(g);
				timer.stop();
			}
	}
}
