package com.skillrisers.gaming.sprites;

import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

public class KenPlayer extends Sprite  {
		
	private BufferedImage walkImages[] = new BufferedImage[6];
	private BufferedImage damageImages[] = new BufferedImage[5];
	private BufferedImage standingImages[] = new BufferedImage[6];
	private BufferedImage kickImages[] = new BufferedImage[5];
	private BufferedImage punchImages[] = new BufferedImage[6];
	private BufferedImage jumpImages[] = new BufferedImage[6];
	public KenPlayer() throws IOException{
		x = GWIDTH - 300;
		y = FLOOR - h;
		imageIndex = 0;
		speed = 0;
		currentMove = STANDING;
		image = ImageIO.read(RyuPlayer.class.getResource(KEN_IMAGE));
		loadWalkImages();
		loadDamageImage();
		loadStandingImages();
		loadKickImages();
		loadPunchImages();
		loadJumpImages();
		}
	
	public void jump() {
		if(!isJump) {
			force = DEFAULT_FORCE;
			y = y + force;
			isJump = true;
			hasLanded = false;
		}
	}
	
	public void fall() {
		if(y>= (FLOOR - h)) {
			isJump = false;
			hasLanded = true;
			return;
		}
		
		force = force + GRAVITY;
		y = y + force;
		
	}
	
	private void loadDamageImage() {
		damageImages[0] = image.getSubimage( 1360 , 3276, 67, 93);
		damageImages[1] = image.getSubimage( 1437 , 3273, 84, 100);
		damageImages[2] = image.getSubimage( 1535 , 3276, 81, 93);
		damageImages[3] = image.getSubimage( 1628 , 3275, 67, 93);
		damageImages[4] = image.getSubimage( 1709 , 3275, 65, 92);
	}
	
	
	private void loadWalkImages() {
		walkImages[0] = image.getSubimage(2034, 867, 55, 94);
		walkImages[1] = image.getSubimage(1970, 864, 62, 94);
		walkImages[2] = image.getSubimage(1893, 865, 62, 94);
		walkImages[3] = image.getSubimage(1824, 866, 62, 94);
		walkImages[4] = image.getSubimage(1756, 862, 62, 94);
		walkImages[5] = image.getSubimage(1682, 866, 62, 94);
	}
	
	private void loadStandingImages() {
		standingImages[0] = image.getSubimage(2032, 868, 58, 90);
		standingImages[1] = image.getSubimage(1968, 866, 58, 90);
		standingImages[2] = image.getSubimage(1892, 867, 65, 90);
		standingImages[3] = image.getSubimage(1820, 864, 65, 90);
		standingImages[4] = image.getSubimage(1749, 864, 65, 90);
		standingImages[5] = image.getSubimage(1684, 868, 60, 90);


	}
	
	private void loadKickImages() {
		kickImages[0] = image.getSubimage(1964 , 1670,  64,  97);
		kickImages[1] = image.getSubimage(1876 , 1670 ,  87,  98);
		kickImages[2] = image.getSubimage(1141 , 1665 ,  65, 99);
		kickImages[3] = image.getSubimage(1057 , 1781 ,  103,  108);
		kickImages[4] = image.getSubimage(1183 , 1767 ,  59,  125);
	}
	
	private void loadPunchImages() {
		punchImages[0] = image.getSubimage(1931 , 1125 , 94 , 119);
		punchImages[1] = image.getSubimage(1866 , 1139 , 63, 105);
		punchImages[2] = image.getSubimage(1791, 1140,	73,  105);
		punchImages[3] = image.getSubimage(1667 , 1140 , 112, 105);
		punchImages[4] = image.getSubimage(1587 , 1141 , 80, 105);
		punchImages[5] = image.getSubimage(1519 , 1140 , 66, 100);
	}
	
	private void loadJumpImages() {
		jumpImages[0]= image.getSubimage(1134, 963, 54, 76);
	}
	
	public BufferedImage walkImage() {
		if(imageIndex > 5) {
			imageIndex = 0;
		}
		
		BufferedImage img = walkImages[imageIndex];
		imageIndex++;
		return img;
	}
	
	public BufferedImage damageImage() {
		if(imageIndex >=5) {
			imageIndex = 0;
			currentMove = STANDING;
		}
		BufferedImage img = damageImages[imageIndex];
		imageIndex++;
		return img;
	}
	
	public BufferedImage standingImage() {
		if(imageIndex >=5) {
			imageIndex = 0;
			currentMove = STANDING;
		}
		BufferedImage img = standingImages[imageIndex];
		imageIndex++;
		return img;
	}
	
	public BufferedImage punchImage() {
		if(imageIndex >=5) {
			imageIndex = 0;
			currentMove = STANDING;
			isAttacking = false;
		}
		BufferedImage img = punchImages[imageIndex];
		imageIndex++;
		return img;
	}
	
	public BufferedImage kickImage() {
		if(imageIndex >=4) {
			imageIndex = 0;
			currentMove = STANDING;
			isAttacking = false;
		}
		BufferedImage img = kickImages[imageIndex];
		imageIndex++;
		return img;
	}
	
	private BufferedImage jumpImage() {
		if(imageIndex > 0) {
			imageIndex = 0;
			if(hasLanded) {
				currentMove = STANDING;				
			}
			isAttacking = false;
		}
		
		BufferedImage img = jumpImages[imageIndex];
		imageIndex++;
		return img;
	}
	
	@Override
	public BufferedImage defaultImage() {
		
		if(currentMove == DAMAGE){
			return damageImage();
		}
		else if(currentMove == WALK) {
			return walkImage();
		}
		else if(currentMove == PUNCH) {
			return punchImage();
		}
		
		else if(currentMove == KICK) {
			return kickImage();
		}
		
		else if(currentMove == JUMP) {
			return jumpImage();
		}
		
		return standingImage();
		
	}
}
