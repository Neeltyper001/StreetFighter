package com.skillrisers.gaming.sprites;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import com.skillrisers.gaming.utils.GameConstants;

public class RyuPlayer extends Sprite  {
	
	private BufferedImage walkImages [] = new BufferedImage[6];
	private BufferedImage standingImages [] = new BufferedImage[6];
	private BufferedImage kickImages [] = new BufferedImage[6];
	private BufferedImage punchImages [] = new BufferedImage[6];
	private BufferedImage jumpImages [] = new BufferedImage[6];
	private BufferedImage damageImages [] = new BufferedImage[2];
	public RyuPlayer() throws IOException {
		x = 170;

		y = FLOOR - h;
		imageIndex = 0;
		speed = 0;
		currentMove = STANDING;
		isOutOfScreen = false;
		image = ImageIO.read(RyuPlayer.class.getResource(RYU_IMAGE));		
		loadWalkImages();
		loadDamageImage();
		loadStandingImages();
		loadKickImages();
		loadPunchImages();
		loadJumpImages();
	}
	

	
	public void jump() {
		if(!isJump) {
			force = DEFAULT_FORCE;
			y = y + force;
			isJump = true;
			hasLanded = false;
		}
	}
	
	public void fall() {
		if(y>= (FLOOR - h)) {
			isJump = false;
			hasLanded = true;
			return;
		}
		
		force = force + GRAVITY;
		y = y + force;
		
	}
	
	private void loadWalkImages() {
		walkImages[0] = image.getSubimage(56, 230, 84, 106);
		walkImages[1] = image.getSubimage(140, 230, 84, 106);
		walkImages[2] = image.getSubimage(217, 232, 84, 106);
		walkImages[3] = image.getSubimage(289, 231, 84, 106);
		walkImages[4] = image.getSubimage(367, 229, 84, 106);
		walkImages[5] = image.getSubimage(445, 228, 84, 106);
	}
	
	private void loadStandingImages() {
		standingImages[0] = image.getSubimage(62, 234, 74, 103);
		standingImages[1] = image.getSubimage(143, 234, 74, 103);
		standingImages[2] = image.getSubimage(218, 234, 74, 103);
		standingImages[3] = image.getSubimage(296, 234, 74, 103);
		standingImages[4] = image.getSubimage(371, 234, 74, 103);
		standingImages[5] = image.getSubimage(447, 234, 68, 113);
//		standingImages[6] = image.getSubimage(465, 0, 74, 103);
//		standingImages[7] = image.getSubimage(531, 0, 74, 103);
	}
	
	private void loadKickImages() {
		kickImages[0] = image.getSubimage(38 ,  1043 ,  69,  103);
		kickImages[1] = image.getSubimage(120 ,  1043 ,  69,  98);
		kickImages[2] = image.getSubimage(198 ,  1040 ,  122, 104);
		kickImages[3] = image.getSubimage(328 ,  1046 ,  72,  99);
		kickImages[4] = image.getSubimage(409 ,  1046 ,  69,  103);
		kickImages[5] = image.getSubimage(482 ,  1045 ,  92,  104);
	}
	
	private void loadPunchImages() {
		punchImages[0] = image.getSubimage(26 , 819 , 70 , 102);
		punchImages[1] = image.getSubimage(106 , 821 , 72, 100);
		punchImages[2] = image.getSubimage(187, 821,	115,  100);
		punchImages[3] = image.getSubimage(310 , 819 , 78, 99);
		punchImages[4] = image.getSubimage(402 , 816 , 108, 102);
		punchImages[5] = image.getSubimage(517 , 821 , 79, 100);
	}
	
	private void loadDamageImage() {
		damageImages[0] = image.getSubimage( 328 , 2524, 83, 101);
		damageImages[1] = image.getSubimage( 238 , 2524, 83, 101);
	}
	
	private void loadJumpImages() {
		jumpImages[0]= image.getSubimage(264, 460, 75, 80);
	}
	
	private BufferedImage damageImage() {
		if(imageIndex > 1 ) {
			imageIndex = 0;
			currentMove = STANDING;
		}
		BufferedImage img = damageImages[imageIndex];
		imageIndex++;
		return img;
	}
	private BufferedImage walkImage() {
		if(imageIndex > 5) {
			imageIndex = 0;
			currentMove = STANDING;
		}
		BufferedImage img = walkImages[imageIndex];
		imageIndex++;
		return img;
	}
	
	private BufferedImage standingImage() {
		if(imageIndex > 5) {
			imageIndex = 0;
		}
		BufferedImage img = standingImages[imageIndex];
		imageIndex++;
		return img;
	}
	
	private BufferedImage kickImage() {
		if(imageIndex > 5) {
			imageIndex = 0;
			currentMove = STANDING;
			isAttacking = false;
		}
		BufferedImage img = kickImages[imageIndex];
		imageIndex++;
		return img;
	}
	
	private BufferedImage punchImage() {
		if(imageIndex > 5) {
			imageIndex = 0;
			currentMove = STANDING;
			isAttacking = false;
		}
		BufferedImage img = punchImages[imageIndex];
		imageIndex++;
		return img;
	}
	
	private BufferedImage jumpImage() {
		if(imageIndex > 0) {
			imageIndex = 0;
			if(hasLanded) {
				currentMove = STANDING;				
			}
			isAttacking = false;
		}
		
		BufferedImage img = jumpImages[imageIndex];
		imageIndex++;
		return img;
	}
	@Override
	public BufferedImage defaultImage() {
		if(currentMove == DAMAGE) {
			return damageImage();
		}
		
		else if(currentMove == WALK) {
			return walkImage();
		}
		
		 else if(currentMove == PUNCH) {
			return punchImage();
		}
		else if(currentMove == KICK) {
			return kickImage();
		}
		
		else if(currentMove == JUMP) {
			return jumpImage();
		}
		return standingImage();
//		
//		BufferedImage img = walkImages[imageIndex];
//		imageIndex++;
//		return img;
	}
}
