package com.skillrisers.gaming;

import javax.swing.JFrame;
import java.io.IOException;

import javax.swing.JOptionPane;

import com.skillrisers.gaming.utils.GameConstants;

public class GameFrame extends JFrame implements GameConstants{
	
	public GameFrame() throws IOException {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle(TITLE);
		setSize(GWIDTH , GHEIGHT);
		setLocationRelativeTo(null);
		Board board = new Board();
		add(board);
//		setExtendedState(JFrame.MAXIMIZED_BOTH); for full size frame
		setVisible(true);
	}

//	public static void main(String[] args) {
//		GameFrame obj = null;
//		try {
//			 obj = new GameFrame();
//
//		}
//		catch(IOException ex) {
//			JOptionPane.showMessageDialog(obj,"Something went wrong...");
//			ex.printStackTrace();
//		}
//	}

}
