package com.skillrisers.gaming.utils;

public interface PlayerConstants {
		
	int STANDING = 1;
	int WALK = 2;
	int PUNCH = 3;
	int KICK = 4;
	int JUMP = 5;
	int DAMAGE = 6;
	int DEFAULT_SPEED = 10;
	int MAX_HEALTH = 500;
}
