package com.skillrisers.gaming.utils;

public interface GameConstants {
		int GHEIGHT = 850;
		int GWIDTH = 1550;
		String TITLE = "My Game- Street Fighter with SkillRisers";
		int FLOOR = GHEIGHT - 110;
		String RYU_IMAGE = "ryu-sprite.gif";
		String KEN_IMAGE = "kenimage.png";		
		int SPEED = 10;
		int GRAVITY = 1;
		int DEFAULT_FORCE = -20;
}
